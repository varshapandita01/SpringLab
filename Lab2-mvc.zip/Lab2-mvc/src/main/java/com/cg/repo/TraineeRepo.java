package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Trainee;

public interface TraineeRepo extends CrudRepository<Trainee, Integer> {

}
